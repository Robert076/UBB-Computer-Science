#include "BidirectionalMap.h"


int BidirectionalMap::h_key(TKey k) {
	return abs(k) % this->m;
}
int BidirectionalMap::h_value(TValue v) {
	return hash(v) % this->m;
}
int BidirectionalMap::hash(TValue v) {
	int sum = 0;
	for (int i = 0; i < v.length(); i++) {
		sum += (char)v[i];
	}
	return sum;
}

BidirectionalMap::BidirectionalMap() {
	this->m = 11;
	this->key_table = new BDMNode*[this->m];
	this->value_table = new BDMNode * [this->m];
	for (int i = 0; i < this->m; i++) {
		this->key_table[i] = nullptr;
		this->value_table[i] = nullptr;
	}
	this->size = 0;
}

BidirectionalMap::~BidirectionalMap() {
	// nodes are shared, it is enough to go through one table and deallocate them
	for (int i = 0; i < this->m; i++) {
		while (this->key_table[i] != nullptr) {
			BDMNode* current = this->key_table[i];
			this->key_table[i] = this->key_table[i]->next_key;
			delete current;
		}
	}
	delete[] this->key_table;
	delete[] this->value_table;
}


void BidirectionalMap::insert(TKey k, TValue v) {
	if (this->size / (this->m * 1.0) >= 0.75) {
		resize();
	}
	
	//check if the key exists
	BDMNode* current = findKey(k);
	if (current != nullptr) { // found the key
		//check if it happens to have the same value. Why remove and re-insert?
		if (current->value == v) {
			return;
		}
		//not the same value. We need to remove it.
		removeNode(current);
	}
	//check if the value exists
	current = findValue(v);
	if (current != nullptr) {
		removeNode(current);
	}
	//now we can add
	BDMNode* newNode = new BDMNode();
	newNode->key = k;
	newNode->value = v;
	
	insertNode(newNode);

}

void BidirectionalMap::insertNode(BDMNode* node) {
	//add at the beginning of the keylist
	int keypos = this->h_key(node->key);
	int valuepos = this->h_value(node->value);
	node->next_key = this->key_table[keypos];
	node->prev_key = nullptr;
	if (this->key_table[keypos] != nullptr) {
		this->key_table[keypos]->prev_key = node;
	}
	this->key_table[keypos] = node;
	//add at the beginning of the valuelist
	node->next_value = this->value_table[valuepos];
	node->prev_value = nullptr;
	if (this->value_table[valuepos] != nullptr) {
		this->value_table[valuepos]->prev_value = node;
	}
	this->value_table[valuepos] = node;
	this->size++;
}

void BidirectionalMap::removeNode(BDMNode* node) {
	//remove a node from both lists
	int keypos = this->h_key(node->key);
	int valuepos = this->h_value(node->value);
	
	//deal with the key_list
	if (this->key_table[keypos] == node) { // if it is the first in the keylist
		this->key_table[keypos] = this->key_table[keypos]->next_key;
		if (this->key_table[keypos] != nullptr) { // it is the only in the keylist
			this->key_table[keypos]->prev_key = nullptr;
		}
	}
	else if (node->next_key == nullptr) { //it is the last in the keylist
		node->prev_key->next_key = nullptr;
	}
	else { // it is between two existing nodes
		node->prev_key->next_key = node->next_key;
		node->next_key->prev_key = node->prev_key;
	}

	//deal with the value_list similarly
	if (this->value_table[valuepos] == node) {
		//it is the first in the valuelist
		this->value_table[valuepos] = node->next_value;
		if (this->value_table[valuepos] != nullptr) {
			this->value_table[valuepos]->prev_value = nullptr;
		}
	}
	else if (node->next_value == nullptr) {
		node->prev_value->next_value = nullptr;
	}
	else {
		node->prev_value->next_value = node->next_value;
		node->next_value->prev_value = node->prev_value;
	}
	//deallocate the node
	delete node;
	this->size--;
}

BidirectionalMap::BDMNode* BidirectionalMap::findKey(TKey k) {
	//find a node with a given key
	int keypos = this->h_key(k);
	BDMNode* current = this->key_table[keypos];
	while (current != nullptr && current->key != k) {
		current = current->next_key;
	}
	return current;
}

BidirectionalMap::BDMNode* BidirectionalMap::findValue(TValue v) {
	//find a node with a given value
	int valuepos = this->h_value(v);
	BDMNode* current = this->value_table[valuepos];
	while (current != nullptr && current->value != v) {
		current = current->next_value;
	}
	return current;
}


TValue BidirectionalMap::search(TKey k) {
	BDMNode* current = findKey(k);
	if (current != nullptr) {
		return current->value;
	}
	else
		return NULL_TVALUE;
}

TKey BidirectionalMap::reverseSearch(TValue v) {
	BDMNode* current = findValue(v);
	if (current != nullptr) {
		return current->key;
	}
	else
		return NULL_TKEY;
}


TValue BidirectionalMap::remove(TKey k) {
	BDMNode* current = findKey(k);
	TValue result = NULL_TVALUE;
	if (current != nullptr) {
		result = current->value;
		removeNode(current);
	}
	return result;
}

void BidirectionalMap::resize() {
	int oldM = this->m;
	this->m = this->m * 2 + 1; //need to change it so that hash function uses the new m
	BDMNode** oldKeyTable = this->key_table;
	this->key_table = new BDMNode*[this->m];
	//this is only needed for deallocating, we will parse the key_table to get the nodes
	BDMNode** oldValueTable = this->value_table;
	this->value_table = new BDMNode*[this->m];
	for (int i = 0; i < this->m; i++) {
		this->key_table[i] = nullptr;
		this->value_table[i] = nullptr;
	}
	for (int i = 0; i < oldM; i++) {
		while (oldKeyTable[i] != nullptr) {
			BDMNode* currentNode = oldKeyTable[i];
			oldKeyTable[i] = oldKeyTable[i]->next_key;
			//no need to set prev for oldKeyTable[i], it will be changed anyway
			//reuse the existing node, set its links to nullptr and insert in the resized table
			currentNode->next_key = nullptr;
			currentNode->prev_key = nullptr;
			currentNode->next_value = nullptr;
			currentNode->prev_value = nullptr;
			insertNode(currentNode);
		}
	}
	//just the arrays, the actual nodes are already joined in the new table
	delete[] oldKeyTable;
	delete[] oldValueTable;
}
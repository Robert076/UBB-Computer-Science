#include "Test.h"
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <assert.h>
#include <algorithm>
#include "BidirectionalMap.h"

using namespace std;

vector<string> randomStrings(int nr, int maxLength) {
	vector<string> strings;

	while(strings.size() < nr) {
		int size = rand() % maxLength + 1;		
		string s = "";
		for (int j = 0; j < size; j++) {
			int letter = rand() % 26 + 97;
			s += (char)letter;
		}
		if (find(strings.begin(), strings.end(), s) == strings.end()) {
			strings.push_back(s);
		}		
	}
	return strings;
}

vector<int> randomInts(int nr) {
	vector<int> ints;

	while(ints.size() < nr) {
		int number = rand() % 100000;
		if (find(ints.begin(), ints.end(), number) == ints.end()) {
			ints.push_back(number);
		}
	}
	return ints;
}


void oneTestMap(int nrElems, int extra, int maxStringLength) {
	vector<string> s = randomStrings(nrElems + extra, maxStringLength);
	vector<int> i = randomInts(nrElems + extra);
	
	BidirectionalMap m;
	for (int j = 0; j < nrElems; j++) {
		m.insert(i[j], s[j]);
	}
	for (int j = 0; j < nrElems; j++) {
		assert(m.search(i[j]) == s[j]);
		assert(m.reverseSearch(s[j]) == i[j]);
	}
	for (int j = nrElems; j < nrElems + extra; j++) {
		assert(m.search(i[j]) == NULL_TVALUE);
		assert(m.reverseSearch(s[j]) == NULL_TKEY);
	}
	for (int j = 0; j < nrElems / 2; j++) {
		assert(m.remove(i[j]) == s[j]);
	}
	for (int j = nrElems; j < nrElems + extra; j++) {
		assert(m.remove(i[j]) == NULL_TVALUE);
	}
	
	for (int j = 0; j < nrElems; j++) {
		m.insert(i[j], s[nrElems - j - 1]);
		m.insert(i[j], s[nrElems - j - 1]);
	}
	for (int j = 0; j < nrElems; j++) {
		assert(m.search(i[j]) == s[nrElems-j-1]);
		assert(m.reverseSearch(s[j]) == i[nrElems-j-1]);
	}


	for (int j = nrElems-1; j >= 0; j--) {
		assert(m.remove(i[j]) == s[nrElems - j - 1]);
	}
	
}


void testMap() {
	oneTestMap(20, 5, 4);
	oneTestMap(100, 10, 5);
	oneTestMap(500, 20, 6);
	oneTestMap(1000, 30, 7);
	oneTestMap(10000, 100, 20);
}
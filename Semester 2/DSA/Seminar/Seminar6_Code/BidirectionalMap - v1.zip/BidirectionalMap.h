#pragma once
#include <string>

using namespace std;

typedef int TKey;
typedef string TValue;
#define NULL_TKEY  -11111
#define NULL_TVALUE  string("")

class BidirectionalMap
{
	struct BDMNode {
		TKey key;
		TValue value;
		BDMNode* next_key;
		BDMNode* prev_key;
		BDMNode* next_value;
		BDMNode* prev_value;
	};

private:
	int m; //size of the table
	BDMNode** key_table;
	BDMNode** value_table;
	int size;


	int h_key(TKey k); //hash function for the key
	int h_value(TValue v); // hash function for the value
	int hash(TValue v); //since values are strings, we need a function to return an int for them.
	void removeNode(BDMNode* node);
	void resize();
	void insertNode(BDMNode* node);
	BDMNode* findKey(TKey k);
	BDMNode* findValue(TValue v);
public:

	BidirectionalMap();
	~BidirectionalMap();

	void insert(TKey k, TValue v);
	TValue search(TKey k);
	TKey reverseSearch(TValue v);
	TValue remove(TKey k); 
};


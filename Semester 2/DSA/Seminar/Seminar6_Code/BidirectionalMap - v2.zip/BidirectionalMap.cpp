#include "BidirectionalMap.h"


int hashCode(TValue v) {
	int sum = 0;
	for (unsigned int i = 0; i < v.length(); i++) {
		sum += (char)v[i];
	}
	return sum;
}

int BidirectionalMap::h_key(TKey k) {
	return abs(k) % this->m;
}
int BidirectionalMap::h_value(TValue v) {
	return hashCode(v) % this->m;
}

BidirectionalMap::BidirectionalMap() {
	this->m = 11;
	this->key_table = new BDMNode*[this->m];
	this->value_table = new BDMNode * [this->m];
	for (int i = 0; i < this->m; i++) {
		this->key_table[i] = nullptr;
		this->value_table[i] = nullptr;
	}
	this->size = 0;
}

BidirectionalMap::~BidirectionalMap() {
	for (int i = 0; i < this->m; i++) {
		while (this->key_table[i] != nullptr) {
			BDMNode* current = this->key_table[i];
			this->key_table[i] = this->key_table[i]->next[ppkey];
			delete current;
		}
	}
	delete[] this->key_table;
	delete[] this->value_table;
}


void BidirectionalMap::insert(TKey k, TValue v) {
	if (this->size / (this->m * 1.0) >= 0.75) {
		resize();
	}
	
	//check if the key exists
	BDMNode* current = findKey(k);
	if (current != nullptr) { // found the key
		//check if it happens to have the same value. Why remove and re-insert?
		if (current->value == v) {
			return;
		}
		//not the same value. We need to remove it.
		removeNode(current);
	}
	//check if the value exists
	current = findValue(v);
	if (current != nullptr) {
		removeNode(current);
	}
	//now we can add
	BDMNode* newNode = new BDMNode();
	newNode->key = k;
	newNode->value = v;
	
	insertNode(newNode);

}

void BidirectionalMap::insertNode(BDMNode* node) {
	//add at the beginnign of the keylist
	int keypos = this->h_key(node->key);
	insertNodeIntoOneHTable(node,this->key_table, keypos, ppkey);
	//add at the beginning of the valuelist
	int valuepos = this->h_value(node->value);
	insertNodeIntoOneHTable(node,this->value_table, valuepos, ppvalue);

	this->size++;
}

void BidirectionalMap::insertNodeIntoOneHTable(BDMNode* node,BDMNode** htable, int posHTable, PPkeyvalue posP){
	node->next[posP] = htable[posHTable];
	node->prev[posP] = nullptr;
	if (htable[posHTable] != nullptr) {
		htable[posHTable]->prev[posP] = node;
	}
	htable[posHTable] = node;
}


void BidirectionalMap::extractNodeFromOneHTable(BDMNode* node, BDMNode** htable, int posHTable, PPkeyvalue posP)
{
	if (htable[posHTable] == node) { // if it is the first in the list
		htable[posHTable] = htable[posHTable]->next[posP];
		if (htable[posHTable] != nullptr) { // it is the only in the list
			htable[posHTable]->prev[posP] = nullptr;
		}
	}
	else if (node->next[posP] == nullptr) { //it is the last in the list
		node->prev[posP]->next[posP] = nullptr;
	}
	else { // it is between two existing nodes
		node->prev[posP]->next[posP] = node->next[posP];
		node->next[posP]->prev[posP] = node->prev[posP];
	}

	return;
}

void BidirectionalMap::removeNode(BDMNode* node) {

	int keypos = this->h_key(node->key);
	extractNodeFromOneHTable(node, this->key_table, keypos, ppkey);

	int valuepos = this->h_value(node->value);
	extractNodeFromOneHTable(node, this->value_table, valuepos, ppvalue);

	//deallocate the node
	delete node;
	this->size--;
}

BidirectionalMap::BDMNode* BidirectionalMap::findKey(TKey k) {
	int keypos = this->h_key(k);
	BDMNode* current = this->key_table[keypos];

//	while (current != nullptr && current->key != k) {
//		current = current->next[ppkey];
//	}

	BDMNode* temp = new BDMNode();
	temp->key = k;
	current = findInList(temp, current , ppkey);
	delete temp;

	return current;
}

BidirectionalMap::BDMNode* BidirectionalMap::findValue(TValue v) {
	int valuepos = this->h_value(v);
	BDMNode* current = this->value_table[valuepos];

	//	while (current != nullptr && current->value != v) {
	//		current = current->next[ppvalue];
	//	}

	BDMNode* temp = new BDMNode();
	temp->value = v;
	current = findInList(temp, current , ppvalue);
	delete temp;

	return current;
}

BidirectionalMap::BDMNode* BidirectionalMap::findInList(BDMNode* nodeIn, BDMNode* listFirstNode, PPkeyvalue posP){
	BDMNode* current = listFirstNode;
	while (current != nullptr) {
		switch (posP){
		case ppvalue:
			if (current->value == nodeIn->value) return current;
			break;
		case ppkey:
			if (current->key == nodeIn->key) return current;
			break;
		}
		current = current->next[posP];
	}
	return current;
}


BidirectionalMap::BDMNode* BidirectionalMap::createEmptyBDMNode(){
	BDMNode* createdNode = new BDMNode();
	createdNode->key= NULL_TKEY;
	createdNode->value = NULL_TVALUE;
	createdNode->prev[ppkey] = nullptr;
	createdNode->prev[ppvalue] = nullptr;
	createdNode->next[ppkey] = nullptr;
	createdNode->next[ppvalue] = nullptr;
	return createdNode;
}

TValue BidirectionalMap::search(TKey k) {
	BDMNode* current = findKey(k);

	if (current != nullptr) {
		return current->value;
	}
	else
		return NULL_TVALUE;
}

TKey BidirectionalMap::reverseSearch(TValue v) {
	BDMNode* current = findValue(v);
	if (current != nullptr) {
		return current->key;
	}
	else
		return NULL_TKEY;
}


TValue BidirectionalMap::remove(TKey k) {
	BDMNode* current = findKey(k);
	TValue result = NULL_TVALUE;
	if (current != nullptr) {
		result = current->value;
		removeNode(current);
	}
	return result;
}

void BidirectionalMap::resize() {
	int oldM = this->m;
	this->m = this->m * 2 + 1; //need to change it so that hash function uses the new m
	BDMNode** oldKeyTable = this->key_table;
	this->key_table = new BDMNode * [this->m];
	//this is only needed for deallocating, we will parse the key_table to get the nodes
	BDMNode** oldValueTable = this->value_table;
	this->value_table = new BDMNode * [this->m];
	for (int i = 0; i < this->m; i++) {
		this->key_table[i] = nullptr;
		this->value_table[i] = nullptr;
	}
	for (int i = 0; i < oldM; i++) {
		while (oldKeyTable[i] != nullptr) {
			BDMNode* currentNode = oldKeyTable[i];
			oldKeyTable[i] = oldKeyTable[i]->next[ppkey];
			//no need to set prev for oldKeyTable[i], it will be changed anyway
			//reuse the existing node, set its links to nullptr and insert in the resized table
			currentNode->next[ppkey] = nullptr;
			currentNode->prev[ppkey] = nullptr;
			currentNode->next[ppvalue] = nullptr;
			currentNode->prev[ppvalue] = nullptr;
			insertNode(currentNode);
		}
	}
	//just the arrays, the actual nodes are already joined in the new table
	delete[] oldKeyTable;
	delete[] oldValueTable;
}

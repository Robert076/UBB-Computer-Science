#include "BidirectionalMap.h"
#include <iostream>
#include "Test.h"

int main() {
	testMap();
	BidirectionalMap m;
	m.insert(23, "ball");
	m.insert(42, "lab");
	m.insert(51, "lack");
	m.insert(122, "moon");
	m.insert(38, "task");
	m.insert(93, "race");
	m.insert(89, "care");
	//m.insert(42, "race");
	cout << m.search(111) << endl;
	cout << m.search(122) << endl;
	cout << m.search(42) << endl;
	cout << m.reverseSearch("care") <<endl;
	cout << m.reverseSearch("task") << endl;
	cout << m.remove(89) << endl;
	cout << m.search(89) << endl;
	cout << m.reverseSearch("care") << endl;
	cout << m.reverseSearch("race") << endl;
	system("pause");
}
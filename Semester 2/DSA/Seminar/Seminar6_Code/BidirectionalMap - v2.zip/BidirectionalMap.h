#pragma once
#include <string>

using namespace std;

typedef int TKey;
typedef string TValue;
int hashCode(TValue); // hashCode is specific to TValue

#define NULL_TKEY  -11111
#define NULL_TVALUE  string("")


class BidirectionalMap
{
	enum PPkeyvalue {ppkey=0,ppvalue=1} ;  // position of the pointer in the array - next or previous  --> ppkey, ppvalue
	struct BDMNode {
		TKey key;
		TValue value;
		BDMNode* next[2];
		BDMNode* prev[2];
	};

private:
	int m; //size of the table
	BDMNode** key_table;
	BDMNode** value_table;
	int size;

	int h_key(TKey k); //hash function for the key
	int h_value(TValue v); // hash function for the value

	void removeNode(BDMNode* node);
	void extractNodeFromOneHTable(BDMNode* node, BDMNode** htable, int posHTable, PPkeyvalue posP);
	void resize();
	void insertNode(BDMNode* node);
	void insertNodeIntoOneHTable(BDMNode* node,BDMNode** htable, int posHTable, PPkeyvalue posP);

	BDMNode* findKey(TKey k);
	BDMNode* findValue(TValue v);
	BDMNode* findInList(BDMNode* nodeIn,BDMNode* listFirstNode, PPkeyvalue posP);

	BDMNode* createEmptyBDMNode();

public:

	BidirectionalMap();
	~BidirectionalMap();

	void insert(TKey k, TValue v);
	TValue search(TKey k);
	TKey reverseSearch(TValue v);
	TValue remove(TKey k); 
};


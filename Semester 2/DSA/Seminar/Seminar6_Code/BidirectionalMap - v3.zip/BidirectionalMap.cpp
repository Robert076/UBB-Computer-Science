#include "BidirectionalMap.h"


int BidirectionalMap::h_key(TKey k) {
	return abs(k) % this->m;
}
int BidirectionalMap::h_value(TValue v) {
	return hash(v) % this->m;
}
int BidirectionalMap::hash(TValue v) {
	int sum = 0;
	for (int i = 0; i < v.length(); i++) {
		sum += (char)v[i];
	}
	return sum;
}

BidirectionalMap::BidirectionalMap() {
	this->m = 11;
	this->key_table = new BDMNode*[this->m];
	this->value_table = new BDMNode * [this->m];
	for (int i = 0; i < this->m; i++) {
		this->key_table[i] = nullptr;
		this->value_table[i] = nullptr;
	}
	this->size = 0;
}

BidirectionalMap::~BidirectionalMap() {
	for (int i = 0; i < this->m; i++) {
		while (this->key_table[i] != nullptr) {
			BDMNode* current = this->key_table[i];
			this->key_table[i] = this->key_table[i]->next_key;
			delete current;
		}
	}
	delete[] this->key_table;
	delete[] this->value_table;
}


void BidirectionalMap::insert(TKey k, TValue v) {
	if (this->size / (this->m * 1.0) >= 0.75) {
		resize();
	}
	
	//check if the key exists
	BDMNode* currentK = findKey(k);
	BDMNode* currentV = findValue(v);

	if (currentK == nullptr && currentV == nullptr) { // none exists, we need new node
		BDMNode* newNode = new BDMNode();
		newNode->key = k;
		newNode->value = v;

		insertNode(newNode);
	}
	else if (currentK != nullptr && currentV == nullptr) { 
		// only key exists. We will keep the node, change the value to new one, remove link from old value list and add in new valuelist 
		TValue oldVal = currentK->value;
		int valuePos = this->h_value(v);
		int oldValuePos = this->h_value(oldVal);
		if (valuePos == oldValuePos) { // new value hashed to the same position as the old one. Just replace value
			currentK->value = v;
		}
		else { // remove from its value list ...
			if (currentK->prev_value == nullptr) { //it was first in its valuelist
				this->value_table[oldValuePos] = currentK->next_value;
				if (currentK->next_value != nullptr) {
					currentK->next_value->prev_value = nullptr;
				}
			}
			else {
				currentK->prev_value->next_value = currentK->next_value;
				if (currentK->next_value != nullptr) {
					currentK->next_value->prev_value = currentK->prev_value;

				}
			}
			//modify value and add to the beginning of new list
			currentK->value = v;
			currentK->prev_value = nullptr;
			currentK->next_value = value_table[valuePos];
			if (value_table[valuePos] != nullptr) {
				value_table[valuePos]->prev_value = currentK;
			}
			value_table[valuePos] = currentK;
		}
	}
	else if (currentK == nullptr && currentV != nullptr) {
		//only the value exists. Remove the node from keylist, change the key and insert in new list
		int keyPos = this->h_key(k);
		int oldKeyPos = this->h_key(currentV->key);
		if (keyPos == oldKeyPos) {
			currentV->key = k;
		}
		else {
			if (currentV->prev_key == nullptr) {
				key_table[oldKeyPos] = currentV->next_key;
				if (key_table[oldKeyPos] != nullptr) {
					key_table[oldKeyPos]->prev_key = nullptr;
				}
			}
			else {
				currentV->prev_key->next_key = currentV->next_key;
				if (currentV->next_key != nullptr) {
					currentV->next_key->prev_key = currentV->prev_key;
				}
			}

			currentV->key = k;
			currentV->prev_key = nullptr;
			currentV->next_key = key_table[keyPos];
			if (key_table[keyPos] != nullptr) {
				key_table[keyPos]->prev_key = currentV;
			}
			key_table[keyPos] = currentV;
		}

	}
	else { //both nodes exist. The value will be completely removed, while the key will have its value changed 
		//(with all the required changes)
		if (currentK != currentV) {
			removeNode(currentV);
			TValue oldVal = currentK->value;
			int valuePos = this->h_value(v);
			int oldValuePos = this->h_value(oldVal);
			if (valuePos == oldValuePos) { // new value hashed to the same position as the old one. Just replace value
				currentK->value = v;
			}
			else { // remove from its value list ...
				if (currentK->prev_value == nullptr) { //it was first in its valuelist
					this->value_table[oldValuePos] = currentK->next_value;
					if (currentK->next_value != nullptr) {
						currentK->next_value->prev_value = nullptr;
					}
				}
				else {
					currentK->prev_value->next_value = currentK->next_value;
					if (currentK->next_value != nullptr) {
						currentK->next_value->prev_value = currentK->prev_value;

					}
				}
				//modify value and add to the beginning of new list
				currentK->value = v;
				currentK->prev_value = nullptr;
				currentK->next_value = value_table[valuePos];
				if (value_table[valuePos] != nullptr) {
					value_table[valuePos]->prev_value = currentK;
				}
				value_table[valuePos] = currentK;
			}
		}
	}

}

void BidirectionalMap::insertNode(BDMNode* node) {
	//add at the beginnign of the keylist
	int keypos = this->h_key(node->key);
	int valuepos = this->h_value(node->value);
	node->next_key = this->key_table[keypos];
	node->prev_key = nullptr;
	if (this->key_table[keypos] != nullptr) {
		this->key_table[keypos]->prev_key = node;
	}
	this->key_table[keypos] = node;
	//add at the beginning of the valuelist
	node->next_value = this->value_table[valuepos];
	node->prev_value = nullptr;
	if (this->value_table[valuepos] != nullptr) {
		this->value_table[valuepos]->prev_value = node;
	}
	this->value_table[valuepos] = node;
	this->size++;
}

void BidirectionalMap::removeNode(BDMNode* node) {
	int keypos = this->h_key(node->key);
	int valuepos = this->h_value(node->value);
	
	//deal with the key_list
	if (this->key_table[keypos] == node) { // if it is the first in the keylist
		this->key_table[keypos] = this->key_table[keypos]->next_key;
		if (this->key_table[keypos] != nullptr) { // it is the only in the keylist
			this->key_table[keypos]->prev_key = nullptr;
		}
	}
	else if (node->next_key == nullptr) { //it is the last in the keylist
		node->prev_key->next_key = nullptr;
	}
	else { // it is between two existing nodes
		node->prev_key->next_key = node->next_key;
		node->next_key->prev_key = node->prev_key;
	}

	//deal with the value_list similarly
	if (this->value_table[valuepos] == node) {
		//it is the first in the valuelist
		this->value_table[valuepos] = node->next_value;
		if (this->value_table[valuepos] != nullptr) {
			this->value_table[valuepos]->prev_value = nullptr;
		}
	}
	else if (node->next_value == nullptr) {
		node->prev_value->next_value = nullptr;
	}
	else {
		node->prev_value->next_value = node->next_value;
		node->next_value->prev_value = node->prev_value;
	}
	//deallocate the node
	delete node;
	this->size--;
}

BidirectionalMap::BDMNode* BidirectionalMap::findKey(TKey k) {
	int keypos = this->h_key(k);
	BDMNode* current = this->key_table[keypos];
	while (current != nullptr && current->key != k) {
		current = current->next_key;
	}
	return current;
}

BidirectionalMap::BDMNode* BidirectionalMap::findValue(TValue v) {
	int valuepos = this->h_value(v);
	BDMNode* current = this->value_table[valuepos];
	while (current != nullptr && current->value != v) {
		current = current->next_value;
	}
	return current;
}


TValue BidirectionalMap::search(TKey k) {
	BDMNode* current = findKey(k);
	if (current != nullptr) {
		return current->value;
	}
	else
		return NULL_TVALUE;
}

TKey BidirectionalMap::reverseSearch(TValue v) {
	BDMNode* current = findValue(v);
	if (current != nullptr) {
		return current->key;
	}
	else
		return NULL_TKEY;
}


TValue BidirectionalMap::remove(TKey k) {
	BDMNode* current = findKey(k);
	TValue result = NULL_TVALUE;
	if (current != nullptr) {
		result = current->value;
		removeNode(current);
	}
	return result;
}

void BidirectionalMap::resize() {
	int oldM = this->m;
	this->m = this->m * 2 + 1; //need to change it so that hash function uses the new m
	BDMNode** oldKeyTable = this->key_table;
	this->key_table = new BDMNode * [this->m];
	//this is only needed for deallocating, we will parse the key_table to get the nodes
	BDMNode** oldValueTable = this->value_table;
	this->value_table = new BDMNode * [this->m];
	for (int i = 0; i < this->m; i++) {
		this->key_table[i] = nullptr;
		this->value_table[i] = nullptr;
	}
	for (int i = 0; i < oldM; i++) {
		while (oldKeyTable[i] != nullptr) {
			BDMNode* currentNode = oldKeyTable[i];
			oldKeyTable[i] = oldKeyTable[i]->next_key;
			//no need to set prev for oldKeyTable[i], it will be changed anyway
			//reuse the existing node, set its links to nullptr and insert in the resized table
			currentNode->next_key = nullptr;
			currentNode->prev_key = nullptr;
			currentNode->next_value = nullptr;
			currentNode->prev_value = nullptr;
			insertNode(currentNode);
		}
	}
	//just the arrays, the actual nodes are already joined in the new table
	delete[] oldKeyTable;
	delete[] oldValueTable;
}